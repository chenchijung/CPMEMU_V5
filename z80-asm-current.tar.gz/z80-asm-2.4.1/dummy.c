void
print_ticks(void)
{
 /* dummy function for acknowledge_bus_request() in z80-cpu.c */
}
